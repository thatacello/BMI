package br.edu.infnet.imc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    float peso;
    float altura;
    float imc;
    String mensagem = "";

    EditText editPeso, editAltura;
    TextView txtResultado;
    Button btCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editPeso = (EditText) findViewById(R.id.pesoId);
        editAltura = (EditText) findViewById(R.id.alturaId);
        txtResultado = (TextView) findViewById(R.id.valorImcId);
        btCalcular = (Button) findViewById(R.id.botaoCalcularId);

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editAltura.getText().toString().trim().equals("") ||
                    editPeso.getText().toString().trim().equals("")){
                    Toast.makeText(MainActivity.this, "Preencha o(s) campo(s) vazio(s)", Toast.LENGTH_SHORT).show();
                } else {
                    peso = Float.parseFloat(editPeso.getText().toString());
                    altura = Float.parseFloat(editAltura.getText().toString());
                    imc = peso / (altura * altura);

                    if (imc < 16) {
                        mensagem = "Magreza grave";
                    } else if (imc >= 16 && imc < 17) {
                        mensagem = "Magreza moderada";
                    } else if (imc >= 17 && imc < 18.5) {
                        mensagem = "Magreza leve";
                    } else if (imc >= 18.5 && imc < 25) {
                        mensagem = "Saudável";
                    } else if (imc >= 25 && imc < 30) {
                        mensagem = "Sobrepeso";
                    } else if (imc >= 30 && imc < 35) {
                        mensagem = "Obesidade Grau I";
                    } else if (imc >= 35 && imc < 40) {
                        mensagem = "Obesidade Grau II (Severa)";
                    } else {
                        mensagem = "Obesidade Grau III (Mórbida)";
                    }

                    txtResultado.setText("IMC: " + String.valueOf(imc) + "\n" + mensagem);

                }
            }
        });
    }

}
